<?php
$servername = "localhost";
$username = "root";
$password = "root";

// Create connection
$conn = mysqli_connect($servername, $username, $password);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
// Create database
$sql = "CREATE DATABASE eceamazon";
if (mysqli_query($conn, $sql)) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . mysqli_error($conn);
}
echo "<br>";



/*Création de la table Item*/
$database = "eceamazon"; /* Le nom de la base */
$db_found = mysqli_select_db($conn, $database);
$sql = "CREATE TABLE Items (
id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
titre text NOT NULL,
prix FLOAT(20) NOT NULL,
vendeur text,
description text,
image text,
quantity int,
nombrevendu int,
categorie text,
auteur text,
maison text,
sports text,
marque text,
artiste text,
dates text,
sexe text,
taille text
)";

if (mysqli_query($conn, $sql)) {
	    echo "Table Items created successfully";
		} else {
		    echo "Error creating table: " . mysqli_error($conn);
		}
echo "<br>";



/*Création de la table Acheteur*/
$sql = "CREATE TABLE Acheteur (
email char(50) PRIMARY KEY,
mdp text,
nom varchar(30),
prenom varchar(30),
adresse text,
cpost int,
ville varchar(30),
pays varchar(30),
ntel int,
tcarte text,
ncarte int,
dcarte date,
ccarte smallint
)";

if (mysqli_query($conn, $sql)) {
    echo "Table Acheteur created successfully";
	} else {
		echo "Error creating table: " . mysqli_error($conn);
		}
echo "<br>";


/*Création de la table Venduer*/
$sql = "CREATE TABLE Vendeur (
email varchar(50) PRIMARY KEY,
pseudo varchar(30),
mdp text,
nom varchar(30),
prenom varchar(30),
pdp text,
image text
)";

if (mysqli_query($conn, $sql)) {
    echo "Table Acheteur created successfully";
	} else {
	    echo "Error creating table: " . mysqli_error($conn);
		}
echo "<br>";


/*Création de la table Admin*/
$sql = "CREATE TABLE Admin (
email char(50) PRIMARY KEY,
mdp text,
nom varchar(30),
pdp text,
image text
)";

if (mysqli_query($conn, $sql)) {
	echo "Table Acheteur created successfully";
	    } else {
		   	echo "Error creating table: " . mysqli_error($conn);
				}
echo "<br>";

    
/*Création de la table Vente*/
$sql = "CREATE TABLE Vente (
id_vente INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
acheteur varchar(30),
quantite int,
dateachat date,
emaill char(50) NOT NULL,
idd int (10) UNSIGNED NOT NULL,
constraint FK_idfk1 foreign key(idd) REFERENCES Items(id),
constraint FK_idfk2 foreign key(emaill) REFERENCES Acheteur(email)
)";
if (mysqli_query($conn, $sql)) {
    echo "Table Acheteur created successfully";
		} else {
		    echo "Error creating table: " . mysqli_error($conn);
				}
echo "<br>";



/*Création de la table Panier*/
$sql = "CREATE TABLE Panier (
id_panier INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
acheteur varchar(30),
quantite int,
emaill char(50) NOT NULL,
idd int (10) UNSIGNED NOT NULL,
constraint FK_idfk3 foreign key(idd) REFERENCES Items(id),
constraint FK_idfk4 foreign key(emaill) REFERENCES Acheteur(email)
)";

if (mysqli_query($conn, $sql)) {
    echo "Table panier created successfully";
	} else {
	    echo "Error creating table: " . mysqli_error($conn);
			}
echo "<br>";
echo "<br>";

///////////////////////////////////////////////INSERTION DES DONNEES///////////////////////////////



//Insertion des acheteurs
$sql = "INSERT INTO Acheteur (email, mdp, nom, prenom, adresse, cpost, ville, pays, ntel, tcarte, ncarte, dcarte, ccarte)
values
    ('jeremyrocaroca@gmail.com','aqwzsx','Roca','Jeremy','13 rue de cotonou','94000','creteil','France','0608097102','Visa','4878','2020-06-01','206'),
    ('leonardo.dicaprio@gmail.com','titanic','DiCaprio','Leonardo','12 rue de la huchette','75005','Paris','France','0676382321','Mastercard','4444','2020-07-02','202'),
    ('popfiotte@gmail.com','meetflix','Fiotte','Pop','37 quai de grenelle','75015','Paris','France','0612345678','Visa','3333','2020-09-22','101'),
    ('ironman@avengers.fr','thanos','Avengers','Tony','45 rue de la mort','69696','bagneux','Vormir','0686389321','Visa','2222','2020-08-02','909'),
    ('aryastark@got.fr','marcheurblanc','Stark','Arya','99 rue du trone de fer','77777','Got','Loin','0675382321','Mastercard','1111','2021-07-02','808')";

if (mysqli_query($conn, $sql)) {
    echo "jeremy created successfully";
    } else {
 		echo "Error creating table: " . mysqli_error($conn);
        	}
echo "<br>";



//Insertion des vendeurs
$sql = "INSERT INTO Vendeur (email, pseudo, mdp, nom, prenom, pdp, image)
values
	('eceamazon@gmail.com','ece','admin','ece','amazon','amazon.jpg','amazon1.jgp'),
	('lydiahadjeb@gmail.com','lyly','got','Hadjeb','Lydia','lydia.jpg','lydia1.jpg'),
	('hudofullgerbe@gmail.com','hudo','Hudo1010','Fougeres','Hugo','hugo.jpg','hugo1.jpg'),
	('jps@gmail.com','jps','info','Segado','Jean Pierre','jps.jpg','jps1.jpg'),
	('queenb@gmail.com','queenb','jayz','Carter','Beyonce','beyonce.jpg','beyonce1.jpg')";

if (mysqli_query($conn, $sql)) {
    echo "jeremy created successfully";
    } else {
        echo "Error creating table: " . mysqli_error($conn);
        	}
echo "<br>";



//Insertion de l'admin
$sql = "INSERT INTO Admin (email, mdp, nom, pdp, image)
values
    ('eceamazon@gmail.com','admin','Eceamazon','xxx','xxx')";

if (mysqli_query($conn, $sql)) {
	echo "jeremy created successfully";
    } else {
   	    echo "Error creating table: " . mysqli_error($conn);
        	}
echo "<br>";



//Insertion des items
$sql = "INSERT INTO Items (titre, prix, vendeur, description, image, quantity, nombrevendu, categorie, auteur, maison, sports, marque, artiste, dates, sexe, taille)
values
    ('Raquette de tennis','40.99','lomepal@gmail.com','raquette de tennis head au prix de 40.99 de couleur noir','raquettetenis.jpg','12','0','Sportsetloisirs','','','tennis','head','','','',''),
    ('Raquette de ping pong','19.99','eceamazon@gmail.com','raquette de ping pong head au prix de 19.99 de couleur noir','raquettepingpong.jpg','220','0','Sportsetloisirs','','','ping pong','head','','','',''),
    ('T-shirt nike','30.99','lydiahadjeb@gmail.com','T-shirt nike au prix de 30.99 de couleur noir en taille M','tshirtnike.jpg','10','0','Vetements','','','','','','','Femme','S'),
    ('Deux freres','20','queenb@gmail.com','Album deux freres de PNL','deuxfreres.jpg','100','0','Musique','','','','','PNL','mars 2019','',''),
    ('Jogging adidas','40.99','jps@gmail.com','jogging adidas au prix de 40.99 de couleur grise','joggingadidas.jpg','5','0','Vetements','','','','','','','Femme','S'),
    ('Harry Potter et la coupe de feu','11.99','jps@gmail.com','quatrieme volet de la saga harry potter','harrypotter.jpg','40','0','Livres','JK Rowling','Londres','','','','','',''),
    ('Trasher magazine','10.50','lomepal@gmail.com','magasine de skate trasher','trashermagazine.jpg','22','0','Livres','culture','skate','','','','','',''),
    ('Trampoline','199.99','lydiahadjeb@gmail.com','trampoline de la marque go sport','trampoline.jpg','14','0','Sportsetloisirs','','','loisirs','go sport','','','',''),
    ('T-shirt adidas','20.99','eceamazon@gmail.com','t shirt adidas de couleur noir de la marque adidas au prix de 20.99','tshirtadidas.jpg','50','0','Vetements','','','','','','','Homme','L'),
    ('Sweat lacoste','60.80','lomepal@gmail.com','Sweat lacoste de couleur grise a 60.80','sweatlacoste.jpg','10','0','Vetements','','','','','','','Homme','M'),
    ('Destin','19.99','hudofullgerbe@gmail.com','album de ninho destin','destin.jpg','50','0','Musique','','','','','Ninho','fevrier 2019','',''),
    ('Temps mort','10.40','queenb@gmail.com','Album Temps mort de Booba','tempsmort.jpg','10','0','Musique','','','','','Booba','Janvier 2010','',''),
    ('Ballon de foot','10.99','lomepal@gmail.com','Ballon de foot nike a 10.99 de couleur grise ','ballonkike.jpg','200','0','Sportsetloisirs','','','football','nike','','','',''),
    ('Homecoming','15.99','lydiahadjeb@gmail.com','Album de beyonce Homecoming','homecoming.jpg','5','0','Musique','','','','','Beyonce','Juin 2018','',''),
    ('Pinnochio','5.99','eceamazon@gmail.com','livre de pinnochio univers disney','pinnochio.jpg','2','0','Livres','walt disney','disney','','','','','',''),
    ('La cigale et la fourmi','4.99','eceamazon@gmail.com','fable de jean de la fontaine la cigale et la fourmi','lacigaleetlafourmi.jpg','50','0','Livres','jean de la fontaine','galimard','','','','','','')


    ";

if (mysqli_query($conn, $sql)) {
	echo "jeremy created successfully";
    } else {
   	    echo "Error creating table: " . mysqli_error($conn);
        	}
echo "<br>";






mysqli_close($conn);
?>