<?php

$stat = isset($_POST["statut1"])?$_POST["statut1"]:"";


if($stat == "Oui, me connecter"){
    
    
    header("Location: connexionvendeur.php");
    }

else if($stat == "Non, m'inscrire"){
    
    header("Location: inscriptionvendeur.php");
    }




?>