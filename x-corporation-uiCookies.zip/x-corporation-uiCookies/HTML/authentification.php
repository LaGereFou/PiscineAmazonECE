<?php
if ($_POST["buttonstatut"]) {
    
    $stat = isset($_POST["statut"])?$_POST["statut"]:"";
    
    if($stat == "Administrateur")
    {
        header("Location:connexionadmin.php");
        
    }
    else if ($stat == "Vendeur")
    {
        header("Location:firstvendeur.php");
        
    }
    else if ($stat == "Acheteur")
    {
        header("Location:firstacheteur.php");
        
    }
    

	}
?>