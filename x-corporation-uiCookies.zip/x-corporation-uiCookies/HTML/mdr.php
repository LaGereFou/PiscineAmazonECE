<?php

echo "coucou";

?>