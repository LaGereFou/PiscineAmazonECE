<?php
	$database = "eceamazon";
	$db_handle = mysqli_connect('localhost', 'root', '');
	$db_found = mysqli_select_db($db_handle, $database);
	$login= isset($_POST["email"])?$_POST["email"] : "";
	$pass    = isset($_POST["mdp"])?$_POST["mdp"] : "";
	$pseudo= isset($_POST["pseudo"])?$_POST["pseudo"] : "";
	if ($_POST["buttonvd"]) {
		if ($db_found) {
			$sql = "SELECT * FROM vendeur";
			if ($login != "") {
				$sql .= " WHERE Email LIKE '%$login%'";
				if ($pseudo != "") {
					$sql .= " AND Pseudo LIKE '%$pseudo%'";
					if ($pass != "") {
						$sql .= " AND Mdp LIKE '%$pass%'";
					}
				}
			}
			$result = mysqli_query($db_handle, $sql);
			if (mysqli_num_rows($result) == 0) {
				echo "Vendeur non trouvé";
				header("Location:inscriptionvendeur.php");
			} else {
				while($data = mysqli_fetch_assoc($result)) {
					echo "Email: " . $data['email'] . '<br>';
					echo "Pseudo: " . $data['pseudo'] . '<br>';
		        	echo "Mdp:" . $data['mdp'] . '<br>';
			        echo "Nom: " . $data['nom'] . '<br>';
			        echo "Prenom: " . $data['prenom'] . '<br>';
			        echo "Pdp: " . $data['pdp'] . '<br>';
			        echo "Image: " . $data['image'] . '<br>';
					}
				} 
			}
		else {
		echo "Database not found";
		}
	}
?>